package Exceptions;

public interface FixAuto {
    public String fix1(int i);
}
