package Adapter;

import Server.AutoServer;

public class BuildAuto extends proxyAutomobile implements AutoServer {


}
