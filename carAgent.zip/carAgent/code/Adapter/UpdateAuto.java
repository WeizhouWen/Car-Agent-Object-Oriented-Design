package Adapter;

public interface UpdateAuto {
    public void updateOptionSetName(String Modelname, String OptionSetname, String
            newName);
    public void updateOptionPrice(String Modelname, String OptionSetname, String
            Option, float newprice);
    public void update_choice(String Modelname, int x);


}
