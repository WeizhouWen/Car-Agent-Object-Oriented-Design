package Adapter;

import java.io.IOException;

public interface CreateAuto {
    public void BuildAuto(String filename) throws IOException;
    public void printAuto(String Modelname);

}
