package Scale;

public interface Editable {
    public void update(String optionset, String old_option, String newc_option, int sync, int threadno);

}
